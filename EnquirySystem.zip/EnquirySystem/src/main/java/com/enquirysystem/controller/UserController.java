package com.enquirysystem.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.enquirysystem.model.Users;
import com.enquirysystem.services.UserServices;

@Controller
public class UserController {

	@Autowired
	private UserServices us;

	@RequestMapping("/home")
	public ModelAndView viewhome() {
		return new ModelAndView("home");
	}

	@RequestMapping("/registerView")
	public ModelAndView viewRegister( ) {
		System.out.println("sfedfggjhg");
		return new ModelAndView("register");
	
	}

	@RequestMapping("/RegisterServlet")
	public ModelAndView RegisterServlet(@ModelAttribute("users") Users u) {
		us.registerUser(u);
		return new ModelAndView("register");
	}

	
}