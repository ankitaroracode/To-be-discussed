package com.enquirysystem.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.enquirysystem.dao.*;
import com.enquirysystem.model.Users;
@Repository
@Component
public class UserServices {

	@Autowired
	UserDao udao;

	public void registerUser(Users u) {
		udao.registerUser(u);
	}

	public Users getUserByUsername(String username) {
		Users u = new Users();
		u = udao.getUserByUsername(username);
		return u;
	}
}