package com.enquirysystem.dao;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.enquirysystem.model.Users;
@Service
@Component
public interface UserDao {
public void registerUser(Users u);
public Users getUserByUsername(String username);
}