package com.enquirysystem.dao;

import java.util.ArrayList;
import javax.persistence.*;
import java.util.List;

import javax.persistence.Query;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.enquirysystem.model.Users;

@Repository
@Component
public class UserDaoImpl implements UserDao {
	@Autowired
	private EntityManager entityManager;

	@Override
	public void registerUser(Users u) {
		Session session = entityManager.unwrap(Session.class);
		session.beginTransaction();
		session.save(u);
		session.getTransaction().commit();

	}

	@Override
	public Users getUserByUsername(String username) {

		Users u = new Users();
		Session session = entityManager.unwrap(Session.class);
		String hql = "from Users where userName =: username";
		Query q = session.createQuery(hql);
		q.setParameter(1, username);
		List<Users> userList = new ArrayList<Users>();
		userList = q.getResultList();
		if (!userList.isEmpty()) {
			return userList.get(0);
		} else {
			return null;
		}
	}
}