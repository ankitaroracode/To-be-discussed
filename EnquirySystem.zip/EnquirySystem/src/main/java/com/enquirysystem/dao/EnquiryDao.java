package com.enquirysystem.dao;

import java.util.List;

import com.enquirysystem.model.Enquiry;

public interface EnquiryDao {
public void addEnquiry(Enquiry e);
public List<Enquiry> getEnqueryByUserId(int id);
public void deleteEnquiry(int id);
public void UpdateEnquiry(Enquiry e);
}
