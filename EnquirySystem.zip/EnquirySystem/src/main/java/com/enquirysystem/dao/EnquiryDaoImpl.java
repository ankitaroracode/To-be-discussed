package com.enquirysystem.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.enquirysystem.model.Enquiry;
import com.enquirysystem.model.Users;

public class EnquiryDaoImpl implements EnquiryDao {
	@Autowired
	private EntityManager entityManager;

	@Override
	public void addEnquiry(Enquiry e) {
		Session session = entityManager.unwrap(Session.class);
		
		session.beginTransaction();
		session.save(e);
		session.getTransaction().commit();

	}

	@Override
	public List<Enquiry> getEnqueryByUserId(int id) {
		Enquiry u = new Enquiry();
		Session session = entityManager.unwrap(Session.class);
		String hql = "from Enquiry where userId =: id";
		Query q = session.createQuery(hql);
		q.setParameter("id", id);
		List<Enquiry> EnquiryList = new ArrayList<Enquiry>();
		EnquiryList = q.getResultList();
		return EnquiryList;
	}

	@Override
	public void deleteEnquiry(int id) {
		Session session = entityManager.unwrap(Session.class);
		String hql  = " delete from Enquiry s  where s.id=:sId";
		Query q = session.createQuery(hql);
		q.setParameter("sId", id);
		q.executeUpdate();
	}

	@Override
	public void UpdateEnquiry(Enquiry e) {
		Session session = entityManager.unwrap(Session.class);
		String hql  = "update Enquiry e set e.enquiry=:enquiry where e.id=:eId";
		Query q = session.createQuery(hql);
		q.setParameter("enquiry", e.getEnquiry());
		q.setParameter("eId", e.getId());
		q.executeUpdate();
		

	}

}
